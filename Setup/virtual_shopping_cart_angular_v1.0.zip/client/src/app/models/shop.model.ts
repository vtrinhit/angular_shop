export interface ShopInfo
{
    name: string,
    phoneNumber: string,
    image: string,
    // "items": Item
    errorMessage: string
  }