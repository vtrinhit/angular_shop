namespace VirtualShopping.Domain.Requests
{
    public class GetOrderReq
    {
        public string OrderId { get; set; }
    }
}